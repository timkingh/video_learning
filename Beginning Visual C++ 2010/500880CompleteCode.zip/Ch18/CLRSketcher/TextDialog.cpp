#include "StdAfx.h"
#include "TextDialog.h"

