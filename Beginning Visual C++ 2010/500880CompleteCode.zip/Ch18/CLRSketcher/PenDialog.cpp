#include "StdAfx.h"
#include "PenDialog.h"

