// Ex2_02.cpp
// Exercising output
#include <iostream>

using std::cout;
using std::endl;

int main()
{
   int num1 = 1234, num2 = 5678;
   cout << endl;                                // Start on a new line
   cout << num1 << num2;                        // Output two values
   cout << endl;                                // End on a new line
   return 0;                                    // Exit program
}
